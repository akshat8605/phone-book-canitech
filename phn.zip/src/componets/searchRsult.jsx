import React, { Component } from 'react'
import './sraechRsult.css'
export class SearchRsult extends Component {
    render() {
        return (
            <div>
                <div className="rechRsult">
                        
                </div>
            </div>
        )
    }
}

export default SearchRsult
