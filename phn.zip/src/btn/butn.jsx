import React, { Component } from 'react'

export class butn extends Component {
    render() {
        return (
            <>
            <div className="btn"></div>
            </>
            )
    }
}

export default butn;
